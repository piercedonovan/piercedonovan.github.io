% Pierce Donovan
% Humpback Chub Modeling: generating the markov transition matrix given problem dynamics
% transition_matrix.m
% last edit: 6/25/18
 
% This generates the Markov transition matrix conditional on the two state
% equations in the chub problem. Uses sparce commands because quick and small.

% Called by pva_parent_script.m
 
function B = transition_matrix(num_u,num_s,num_sx,num_sy,Sx,Sy,trout_pmf,chub_pmf)

% initializing stochastic transition matrix (index -> trout-chub tuple)
% so we remember: 2 states means [(trout state 1)(go thru chub);[(trout state 2)(go thru chub);...]
max_u = num_u-1;
B = containers.Map(0:max_u,{[],[],[],[],[],[],[]}); % better than cell, like a zip file
for h = 0:max_u % loop through actions
 
    [id_new, id_old, tc_pmf] = deal([]);    
 
    for i = 1:num_sx % loop through old trout states
        % trout distribution given old trout and action
        [t_pmf,t_loc] = trout_pmf(Sx(i),h);
        num_t_loc = length(t_loc);
        
        for j = 1:num_sy % loop through old chub states
             
            % chub placement given old chub and trout
            [c_pmf,c_loc] = chub_pmf(Sy(j),Sx(i));
            num_c_loc = length(c_loc);
            num_loc = num_t_loc*num_c_loc;

%             if any(c_pmf<0) % debug negative chub
%                 error('negative pmf values')
%             end
            
%             if any(isnan(t_pmf)) % debug log(0) trout
%                 error('tNAN')
%             end

            % (feasible) trout by (feasible) chub pmf (before stacking in vector)
            tc_pmf_ij = reshape(c_pmf*t_pmf',num_loc,1); % Dim 1: chub, dim 2: trout.  Reshape: first trout, go through chub...
             
            % append new non-zero entries to the matrix
            tc_pmf = [tc_pmf;tc_pmf_ij];
 
            % find where all non-zero entries belong in full trout-chub state space
            id_new_ij = [reshape(repmat(t_loc,1,num_c_loc)',num_loc,1)...     %chub (dim1) by trout (dim2) before stacking
                         reshape(repmat(c_loc,1,num_t_loc) ,num_loc,1)];      
                      
            id_new_ij = (id_new_ij(:,1)-1)*num_sy+id_new_ij(:,2); % convert to combined chub-trout state index
            id_new = [id_new;id_new_ij]; % append to grand vector
             
            id_old_ij = (i-1)*num_sy+j; % convert starting index to chub-trout state
            id_old = [id_old;repmat(id_old_ij,num_loc,1)]; % replicate starting index to same size as new index
 
        end % chub
     
    end % trout
      
    % building the transition matrix, given action
    % (since a transition matrix, all rows should sum to 1)
    B(h) = sparse(id_old,id_new,tc_pmf,num_s,num_s);
    
    % progress output
    % disp(['Action ' num2str(h) ' complete. ']);
                
end % action
 
% check (fixed: never use full(), you can sum across sparse matricies instantly)
% if turned on, used to say failed, but machine precision error, all ones
%     disp('Checking MTM B for each action')
%     for i = 0:6
%        disp(i)
%        if sum(round(sum(B(i),2),10)~=1) % ALT: if sum(sum(B(i),2)~=1)
%             error('Problem with Markov transition matrix B: rows do not sum to 1');
%        end
%     end

end


