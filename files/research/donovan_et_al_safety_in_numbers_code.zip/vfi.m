% Pierce Donovan
% Humpback Chub Modeling: Dynamic optimization script
% dyno_opt.m
% last edit: 6/25/18

% This generates the policy for the given dynamic problem and the
% corresponding value function using value function iteration (vfi) to find
% the fixed point of the Bellman equation. (inf horizon)
% (pretty generalized code with a few tweaks to the chub problem)

% Called by population_viability.m

function [value, policy] = vfi(v_old,penalty,bell,U,num_u,num_s,num_sy)

% stopping criterion (proportional terms)
epsilon_v = 0.01; % set value function tolerance

% infinity-norm (largest element) [conservative]
norm = @(v_new,v_old) max(abs((v_new-v_old)./v_old)); % to calculate maximum absolute relative change in value function

% loop prep
dv = epsilon_v + 1; % maximum absolute relative change in value function -- start w/ value greater than epsilon


%% solve for fixed point

while dv > epsilon_v
    
    % for each control u in U, apply the bellman operator
    v_mat = zeros(num_s,num_u);
    for i = min(U):max(U)
        v_mat(:,i+1) = bell(i,v_old);
    end
    
    % getting value function, policy function that maximizes value
    [v_new,u_idx] = max(v_mat,[],2); % Bellman operator
    v_new(1:num_sy:num_s) = penalty; % reset viability state value, don't care about action assigned here (set to max later)
    
    % calculate change in value function
    dv = norm(v_new,v_old);
    v_old = v_new;
    
end

% output
value = v_new;
policy = u_idx - 1; % fix so action is literal, not index

end


