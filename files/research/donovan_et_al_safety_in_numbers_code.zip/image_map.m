% Pierce Donovan
% Humpback Chub Modeling: Making for cleaner parent plotting code
% imagemap.m
% last edit: 6/25/18

% Just thought since this code keeps repeating that I'd make a separate function.

function image_map(data,Sy,Sx)

imagesc(data,'AlphaData',~isnan(data));
% image(data,'CDataMapping','scaled'); % base heatmap
colorbar; % add scale
xlabel('trout abundance, X');
ylabel('chub abundance, Y');

% axes labels and other things (some custom numbers here, cuidate)
num_x = (max(Sx)-min(Sx))/900 + 1;
num_y = round((max(Sy)-min(Sy))/2000 + 1);
for i = 1:num_x
    [~, idx(i)] = min(abs(Sx-(min(Sx)+(i-1)*900)));
end
for i = 1:num_y
    [~, idy(i)] = min(abs(Sy-(min(Sy)+(i-1)*2000)));
end
xticks(idx)
yticks(idy)
xticklabels(round(Sx(idx),-2))
yticklabels(round(Sy(idy),-3))

grid on

end


