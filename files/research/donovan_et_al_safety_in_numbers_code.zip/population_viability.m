% Pierce Donovan
% Humpback Chub Modeling: actually running the structural model
% population_viability.m
% last edit: 6/25/18

% This does the heavy lifting for pva_parent_script.m, calling the VFI to get the
% optimal policy and generating the Markov transition matrix under the
% optimal policy. Also calculates the probability of hitting the threshold
% and the joint chub-trout pmf in T years, given each starting state.

% Called by pva_parent_script.m, penalty_estimation.m

% varargout order: value, density, risk_to_go, shadow, cost

function [policy_map,varargout] = population_viability(v0,penalty,bell,B,U,num_u,num_s,num_sy,num_sx,T,f_value)

%% compute optimal value and policy functions

disp('Running VFI for optimal policy (policy)')
tic
[value,policy] = vfi(v0,penalty,bell,U,num_u,num_s,num_sy); % transition matrix sparce here
toc

% make policy into a grid
policy_map = reshape(policy,num_sy,num_sx);
value = reshape(value,num_sy,num_sx);

% we want to code the dire region as N/A, but make sure the cost takes
% account of max action in this region
temp = cumsum(policy_map)==0;
policy_temp = policy_map;
policy_temp(temp) = max(U);
policy = policy_temp(:); % hardcoded max(U) for viability, density, cost computation
policy_map(temp) = NaN; % coded as N/A for visualization


%% analytics beyond the policy and value functions

if nargout > 0 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    varargout{1} = value;
end

if nargout > 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% grab ideal actions at each state; new transition matrix (2D now)
disp('Generating MTM given policy function (B_opt)')
B_opt = transition_matrix_opt(policy,num_s,B); % sub-selection of B
B_opt = full(B_opt); % makes latter parts save memory, but no speed decrease


%% calculate probability of violating constraint, future density

% make a dumb initial state, make a function that gives expectation of
% absorbing state ( E[f_k(x)] = X_0'*B^T*f(x) )
X_0 = zeros(1,num_s);
X_0(535) = 1; % just some random state that isn't an absorbing state
f_k = zeros(num_s,1);
f_k(1:num_sy:num_s) = 1; % indicator function for absorbing state

% this is the fastest way to multiply matricies with a vector on the end
% this grabs us the density under the optimal and the prob of violating
% constraint in both max and optimal cases (could grab dens under max too)
disp('Generating future density, risk-to-go at T (density, risk_to_go)')
tic
density = X_0*B_opt;
risk_to_go = B_opt*f_k;
for i = 2:T
    density = density*B_opt;
    risk_to_go = B_opt*risk_to_go;
end
toc


% reshape things for later use (plotting), vararging-out
density = reshape(density,num_sy,num_sx);
risk_to_go = reshape(risk_to_go,num_sy,num_sx);

varargout{2} = density;
varargout{3} = risk_to_go;

end


%% compute present shadow value of the viability restriction
if nargout > 4 % then do shadow and cost functions, is expensive for large num_s
    
tic
disp('Generating present shadow value (shadow)')
% solving for v with unmodified bellman operator
cost = f_value(B_opt,policy);
cost = reshape(cost,num_sy,num_sx);

% difference out the cost from the value function, flip shadow value sign
shadow = cost - value; % present shadow value
toc

varargout{4} = shadow;
varargout{5} = cost;


end % nargout


