% Pierce Donovan
% Humpback Chub Modeling: grabbing the Markov transition matrix w.r.t. optimal policy
% transition_matrix_opt.m
% last edit: 6/25/18

% This generates the Markov transition matrix, conditional on the two state
% equations in the chub problem and the optimal action (3D -> 2D).

% Called by population_viability.m

function B_opt = transition_matrix_opt(policy,num_s,B)

% rather than looking at optimal policy for every given state, look at what
% states use a given policy, this should be faster:

states = 1:num_s; % enumerate states for lookup
for h = min(policy):max(policy)

    % building part of the transition matrix, given action
    idx = states(policy==h); % find relevant rows to grab
    B_opt(idx,:) = subsref(B(h),substruct('()',{idx,':'})); % multilevel indexing!
    
    % progress output
    % disp(['Action ' num2str(h) ' complete. ']);
    
end

end


