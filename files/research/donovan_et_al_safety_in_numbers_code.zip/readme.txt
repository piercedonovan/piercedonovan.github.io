Pierce Donovan
PhD. Student, Agricultural and Resource Economics
University of California, Davis
donovan@ucdavis.edu
June 2018

The Matlab code in this directory solves the base model found in Donovan et al. 2018. Open pva_parent_script.m to run the suite. Questions/comments can be directed toward Pierce Donovan.

Copyright 2018 Pierce Donovan. donovan@ucdavis.edu


