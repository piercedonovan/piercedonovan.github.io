% Pierce Donovan
% Humpback Chub Modeling: Parent Script
% pva_parent_script.m
% last edit: 6/25/18

% This calls all of the auxillary scripts in the same folder that store
% program parameters and some frequently-used functions
% (params_functions.m), generate the Markov transition matrix under program
% dynamics (transition_matrix.m), and calculate the optimal program policy
% and generate the probability of violating a viability constraint (vfi.m,
% via population_viability.m).

% For two state-space discretizations, penalty values are already provided.
% In the case where the user wants to estimate a new penalty (under new
% parameter values), then simply change the switch below to 'on'.

% This script plots several items of interest. In order of appearance,
% these are the optimal policy function, the joint chub-trout pmf and
% risk-to-go (conditional on starting state) at time T, and the value,
% cost, and present shadow value functions conditional on starting state.
% These all take the form of heatmaps, or "lookup tables," as they give
% values as a function of two variables. Lastly, a "sliver" of the value
% function is decomposed into cost and shadow value components, shown as a
% function of the present chub state, at the modal value of trout.


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Mise en place

clear variables; close all; clc
dbstop if error


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Setting parameters, functions, etc.
 
params_functions % refresh params mat file
load('params_functions.mat') % load-in various parameters

% initializing stochastic transition matrix, I wanted to call it B
% so we remember, 2 states means [(trout state 1)(go thru chub);(trout state 2)(go thru chub);...]
B = transition_matrix(num_u,num_s,num_sx,num_sy,Sx,Sy,trout_pmf,chub_pmf);

% initial guess of value function and penalty
v0 = -C(ones(num_s,1))/rho; % present value of one removal forever no matter what trout/chub state

% initialize bellman equation, function of action, not action index.
bell = @(A,v_old) -C(A) + delta * B(A) * v_old;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Penalty estimation (on/off)

% We can either run the full estimation, or save a minute or two and
% work with some pre-existing values to solve the dynamic program once.
% Also serves as a check to make sure the estimation proceedure still works.
estimation = 'off';
switch estimation
    case 'on' % run the penalty estimation proceedure
    
        penalty = penalty_estimation(B,v0,bell,U,num_u,num_s,num_sy,num_sx,T,f_value,confidence,epsi);
    
    case 'off' % just take a pre-computed value given the parameters in params_functions
    
        if     num_sy*num_sx == 50*50;   penalty = -1.7 * 10^8;
        elseif num_sy*num_sx == 100*100; penalty = -3.8 * 10^8;
        else   error('Error: Desired point density not pre-computed.')
        end
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Structural programming piece, given a penalty from above

% set threshold violation value
v0(1:num_sy:num_s) = penalty;

[policy_map,value,density,risk_to_go,shadow,cost]...
    = population_viability(v0,penalty,bell,B,U,num_u,num_s,num_sy,num_sx,T,f_value);

% trace where the risk-to-go function is binding
[~,ind_10] = max(risk_to_go < (confidence+epsi),[],1);

% find some isoquants of the joint pmf
isos = density_isos(density,num_sy,num_sx);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plotting

imagemap = @(data)image_map(data,Sy,Sx);


%% policy function (optimal action, conditional on chub-trout state)

figure
imagemap(policy_map)
ax = gca;
ax.Color = [.45,.45,.45]; % gray out NaNs
hold on
plot(1:num_sx,ind_10,'-r','linewidth',2)
contour(density,isos,'-w','Linewidth',2)
title('Policy Function (w/ density, viability constraint overlay)')


%% density (joint pmf of chub-trout states after T years)

figure
imagemap(density)
title('Joint Probability Mass Function at T')


%% risk-to-go (probability of violating threshold within T years, conditional on starting state)

figure
imagemap(risk_to_go)
title('Risk-to-go at T')


%% value function (optimized function, expected present value out to inf, conditional on starting state)

figure
imagemap(-value)
title('Expected Value Function (-$)')


%% expected present cost (out to inf, conditional on starting state)

figure
imagemap(-cost)
title('Expected Present Cost ($)')


%% present shadow value (penalty discounted in time and likelihood of threshold, or remainder of value minus cost, conditional on starting state)

figure
imagemap(shadow)
title('Present Shadow Value ($)')


%% value decomposition cutout (for modal trout outcome, value as a function of chub state)

% grab most likely trout, draw line of chub that goes through it for value
[~,temp]=max(sum(density,1));
h = area(Sy,[-(value(:,temp)+shadow(:,temp))/10^6,shadow(:,temp)/10^6]);
xlim([4500,7500]) % arbitrary, illustrative
ylim([-.5,12])
h(1).FaceColor = [0,0.447,0.741];
h(2).FaceColor = [0.85,0.325,0.098]; % for grayscale: h(2).FaceColor = [0.73,0.83,0.96];
xlabel('chub abundance, Y')
ylabel('$ (millions)')
legend('Expected present cost, EPC(Y|X)','Present shadow value, \omega(Y|X)','location','northeast');


