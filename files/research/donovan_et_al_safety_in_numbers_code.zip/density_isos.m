% Pierce Donovan
% Humpback Chub Modeling: Grabbing custom contour lines from a density plot
% density_isos.m
% last edit: 6/25/18

% It's nice to superimpose isoquants of the resulting density plot on top
% of the policy function, so I'm making that possible here. Use with the
% contour command, like this: contour(dens,isos,'-w','Linewidth',2).

function isos = density_isos(dens,num_sy,num_sx)

% want 10%, 25%, 50% isoclines
% need to find least terms that sum to target
[~,~,rankd] = unique(dens);
rankd = reshape(rankd,num_sy,num_sx);

% use the ranking to sequentially add up density values from biggest to smallest
i = max(rankd(:));
summ = 0;
iso_10 = zeros(num_sy,num_sx);
while summ < .1
    summ = summ + dens(rankd == i);
    iso_10 = iso_10 + (rankd == i);
    i = i - 1;
end % finished the first one, move on to next
iso_25 = iso_10;
while summ < .25
    summ = summ + dens(rankd == i);
    iso_25 = iso_25 + (rankd == i);
    i = i - 1;
end % finished second isoquant
iso_50 = iso_25;
while summ < .50
    summ = summ + dens(rankd == i);
    iso_50 = iso_50 + (rankd == i);
    i = i - 1;
end % finished last

% now contours; the above made a patch, we want the edge so we take the
% lowest points on the patch (works because single-peaked pmf)
isos = [min(min(dens(iso_50==1))),...
        min(min(dens(iso_25==1))),...
        min(min(dens(iso_10==1)))];
    
end


