% Pierce Donovan
% Humpback Chub Modeling: creating a useful .mat file for the population viability problem
% params_functions.m
% last edit: 6/25/18

% This script stores all of the biological and economic parameters in the chub
% problem, as well as initial conditions. Also stored are the trout and
% chub state equations.

% Called by pva_parent_script.m
% Creates a .mat file for problem initialization

function params_functions

%% listing all natural/economic parameters

% state and control sets
trout_min = 0; % smallest bin of trout pop
trout_max = 4500; % mainstem carrying capacity
chub_viability_target = 4000; % minimum value
chub_bar = chub_viability_target; % easier
chub_max = 12000; % mainstem carrying capacity
num_sx = 50; % different than num_sy for debugging
num_sy = 50;
num_s = num_sx*num_sy;
num_u = 7; % number of removal possibilities

% discretizing state, choice variables
Sx = linspace(trout_min,trout_max,num_sx)';
Sx_mid_lo = [trout_min; Sx(2:end) - diff(Sx)/2]; % uniform, midpoint values
Sx_mid_hi = [Sx(1:end-1) + diff(Sx)/2; trout_max];

% switching chub to non-uniform grid
uni = 0; % defined backwards...
if uni
    Sy = linspace(chub_viability_target,chub_max,num_sy)'; % uniform grid
    Sy_mid_lo = [chub_bar; Sy(2:end) - diff(Sy)/2]; % uniform, midpoint values
    Sy_mid_hi = [Sy(1:end-1) + diff(Sy)/2; chub_max];
else % non-uniform grid.  more dense at low values.
    eta_temp = 0.95;
    step_grth_rt_max = 1/eta_temp -1; % step growth rate max for chubb (to allow for declines due to nat mort).
    rt = (chub_max/chub_bar).^(1/(num_sy-1)) - 1; %chosen to achieve same max (3.8e5) in same number of steps as orig (161).  Solves: chub_bar*(1+rt)^(num_sy-1) = chub_max
    if rt>step_grth_rt_max; disp('Check chub vector'); pause; end
    Sy = 4000*((1+rt).^(0:(num_sy-1)))';
    Sy_mid_lo = [chub_bar; Sy(2:end) - diff(Sy)/2]; % nonuniform, midpoint values
    Sy_mid_hi = [Sy(1:end-1) + diff(Sy)/2; chub_max];
end

% possible choice vector, plays nice with eventual bellman equation
U = linspace(0,6,num_u)';

% biological parameters
alpha_x = 11; % lower trout recruitment bound
beta_x = 14; % upper trout recruitment bound
alpha_y = 4000; % lower chub recruitment bound
beta_y = 35000; % 50000; % upper chub recruitment bound
psi_x = 0.397*0.437*0.02; % trout outmigration rate to management zone, (rate*survival)
psi_y = 0.1; % 0.4*0.16; % outmigration * new adults
gamma = 0.61; %0.96^12; % trout survival rate after natural mortality
eta = .83; %0.985^12; % chub adult natrual mortality in mainstem 
c = 75000; % cost of each removal trip
pass = 5; % number of passes per trip
theta = 0.011; %0.045; %0.1; % removal efficacy
mu = 5; %4.8; %3.9+(.73*950)/800; % linear trout efficacy term
lambda = -0.0009; %-.73/800; % base trout efficacy term

% economic parameters
confidence = 0.10; % target pop viability confidence
rho = 0.03; % continuous discount rate
delta = 1/(1+rho); % discrete discount factor
T = 20; % time horizon (in years)

% fudging goal threshold to account for float/discrete error, helps with convergence time
epsi = 0.001;


%% functions now

% initializing program functions
C = @(A) c*A; % removal cost
rem = @(A) (1-theta).^(pass*A); % after removal
via = @(X) (1./(1+exp(-(mu+lambda*X)))).^12; % chub viability, now with lambda argument

% value function (without penalties involved) % eye(num_s) * 
f_value = @(B,U) (eye(num_s)-delta*B) \ -C(U); % starting at t=0

% trout pmf (passing parameters to below, folds chunky code into an anonymous function)
trout_pmf = @(X_old,A) f_trout_pmf(X_old,A,alpha_x,beta_x,Sx,Sx_mid_lo,Sx_mid_hi,rem,gamma,psi_x);

% chub pmf (another useful anon function)
chub_pmf = @(Y_old,X_old) f_chub_pmf(Y_old,X_old,via,psi_y,alpha_y,beta_y,eta,Sy,Sy_mid_lo,Sy_mid_hi,chub_bar);

% saving the parameters and functions, for use everywhere else
save('params_functions.mat');

end


% this function creates a pmf for trout, conditional on current state and action
function [t_pmf,t_id] = f_trout_pmf(X_old,A,alpha_x,beta_x,Sx,Sx_mid_lo,Sx_mid_hi,rem,gamma,psi_x)

    % NEW PLAN: evaluate pmf everywhere, even non-valid states. Just insist
    % on 0's where there should be some. (As opposed to taking feasible [new]
    % trout states and only computing the pmf over those states.)
    
    % input: old trout state, current number of removals
    % output: new trout state density, truncated to list only non-zero entries (and indicies)
    
    % lets grab those bounds for feasibility
    t_lo = (X_old + psi_x*exp(alpha_x))*rem(A)*gamma;
    t_hi = (X_old + psi_x*exp(beta_x))*rem(A)*gamma;
    
    % calculate the cdf at all of these midpoints (evaluated at midpoint vector to get density right)
    trout_cdf_lo = ((Sx_mid_lo >= t_lo) & (Sx_mid_lo <= t_hi)) .* ...
        (1/(beta_x-alpha_x)*(log((Sx_mid_lo-X_old*rem(A)*gamma)/(psi_x*rem(A)*gamma))-alpha_x)); % log-uniform cdf
    
    trout_cdf_hi = ((Sx_mid_hi >= t_lo) & (Sx_mid_hi <= t_hi)) .* ...
        (1/(beta_x-alpha_x)*(log((Sx_mid_hi-X_old*rem(A)*gamma)/(psi_x*rem(A)*gamma))-alpha_x));
    
    % fix NaNs (arises from cdf having a log in it, which is undefined at 0)
    trout_cdf_lo(isnan(trout_cdf_lo)) = 0;
    trout_cdf_hi(isnan(trout_cdf_hi)) = 0;
    
    % accounting for special case where the interval is too small and doesn't bound any lattice points
    if max(trout_cdf_lo) ~= 0 % "normal" case
    
        % hardcode in a 1 before taking the difference of the two vectors
        [~,id_max_valid] = max(trout_cdf_lo);
        trout_cdf_hi(id_max_valid) = 1;

        % calculate the pmf as the differences between the cdfs
        t_pmf = trout_cdf_hi - trout_cdf_lo; % grab pmf    
        % debug: [Sx,Sx_mid_lo,Sx_mid_hi,t_pmf];

        % make friendly with sparce matrix stuff in B calculations
        t_id = find(t_pmf); % indicies of valid states
        t_pmf = t_pmf(t_id); % valid state densities
        
    else % tiny interval completely between two nodes (or absorbing issue)
        
        % this case doesn't even happen, watch:
        % so special cases only needed for chub, where hi and lo states get
        % squished together by the trout effect + tiny migration
        disp('heyo') % see look didn't happen
        
%         commented out b/c no absorbing state for trout:
%         if X_old > trout_min % interval actually is too small

            % find the closest two points, and split the pmf
            t1 = find(t_lo > Sx,1,'last');
            t2 = t1 + 1;

            if isempty(t1) % going to the absorbing state

                % if interval below, go straight to ground
                t_pmf = 1; % ground state lockdown
                t_id = 1;

            else % not ending up at lowest

                % calculate distance to lower bound, determine fraction to split
                t_pmf(1) = (Sx(t2)-(t_lo+t_hi)/2) / (Sx(t2)-Sx(t1));  % (locally uniform)
                t_pmf(2,1) = 1 - t_pmf(1);
                t_id = [t1; t2]; % index vector

            end % going to absorbing
        
%         else % at absorbing state
%             
%             t_pmf = 1; % ground state lockdown
%             t_id = 1;
%             
%         end % at absorbing
        
    end % tiny interval
        
    
end % f_trout_pmf


% this function creates a pmf for chub, conditional on current trout/chub states
function [c_pmf,c_id] = f_chub_pmf(Y_old,X_old,via,psi_y,alpha_y,beta_y,eta,Sy,Sy_mid_lo,Sy_mid_hi,chub_bar)

    % NEW PLAN: evaluate pmf everywhere, even non-valid states (same as above)
    % input: old trout state, old chub state
    % output: new chub state density, truncated to list only non-zero entries (and indicies)
    
    % compute feasible bounds
    c_lo = (Y_old*eta + psi_y*via(X_old)*alpha_y) * (Y_old > chub_bar) + chub_bar * (Y_old <= chub_bar);
    c_hi = (Y_old*eta + psi_y*via(X_old)*beta_y) * (Y_old > chub_bar) + chub_bar * (Y_old <= chub_bar);
    
    % calculate the chub cdf
    chub_cdf_lo = ((Sy_mid_lo >= c_lo) & (Sy_mid_lo <= c_hi)) .* ...
        (1/(beta_y-alpha_y)*(1/(psi_y*via(X_old)))*(Sy_mid_lo-c_lo)); % uniform cdf

    chub_cdf_hi = ((Sy_mid_hi >= c_lo) & (Sy_mid_hi <= c_hi)) .* ...
        (1/(beta_y-alpha_y)*(1/(psi_y*via(X_old)))*(Sy_mid_hi-c_lo));

    % accounting for special case where the interval is too small and doesn't bound any lattice points
    if max(chub_cdf_lo) ~= 0 % "normal" case
        
        % correct last node of the cdf
        [~,id_max_valid] = max(chub_cdf_lo);
        chub_cdf_hi(id_max_valid) = 1;

        % calculate the pmf as the differences between the cdfs
        c_pmf = chub_cdf_hi - chub_cdf_lo; % grab pmf  
        % debug: [Sy,Sy_mid_lo,Sy_mid_hi,c_pmf];

        % last bug, some density under the ground state sometimes becomes
        % non-trivial, so I tack it on manually
        if c_lo < chub_bar
            c_pmf(1) = c_pmf(1) + 1 - sum(c_pmf);
        end
        
        % make friendly with sparce matrix stuff in B calculations
        c_id = find(c_pmf); % indicies of valid states
        c_pmf = c_pmf(c_id); % valid state densities
    
    else % tiny interval completely between two midpoint nodes (or absorbing issue)
        
        if Y_old > chub_bar % interval actually is too small
            
            % find the closest point and dump pmf
            c_id = find(c_lo > Sy_mid_lo,1,'last'); % snap to this
            if isempty(c_id); c_id = 1; end % below absorbing fix
            c_pmf = 1; % uniquely here

        else % starting at the absorbing state
            
            c_pmf = 1; % ground state lockdown
            c_id = 1;
            
        end % at absorbing
        
    end % tiny interval
    
    % check chub pmf issue
%     if round(sum(c_pmf),2) ~= 1
%         error('Bad chub pmf, dont sum to one.')
%     end

    
end % f_chub_pmf


