% Pierce Donovan
% Humpback Chub Modeling: estimation of a structural parameter
% penalty_estmation.m
% last edit: 6/25/18

% Estimates the value of a penalty parameter used to motivate costly action
% in the population viability problem.

% Called by pva_parent_script.m


function penalty = penalty_estimation(B,v0,bell,U,num_u,num_s,num_sy,num_sx,T,f_value,confidence,epsi)

%% Benchmark: max degenerate action case

B_max = full(B(6));
f_k = zeros(num_s,1);
f_k(1:num_sy:num_s) = 1;
risk_to_go_max = B_max*f_k;
for i = 2:T
    risk_to_go_max = B_max*risk_to_go_max;
end
risk_to_go_max = reshape(risk_to_go_max,num_sy,num_sx);
[~,ind_10_max] = max(risk_to_go_max<confidence,[],1); % target: last feasible at 10%

%% Penalty Estimation

% helpful anonymous function
pop_viability = @(v0,omeguess) population_viability(v0,omeguess,bell,B,U,num_u,num_s,num_sy,num_sx,T,f_value);

% initial range of penalty parameter considered
omega_0 = -[100000000, 1000000000];

% loop tolerance, simple ending condition
tol = 0.05;

% loop, test mean of bounds, if good, new upper bound, bad, lower bound, and converge within some tolerance
omega = omega_0;
distance = 1;
while distance > tol % tolerance percent diff in bounds
    
    % set up next guess
    omeguess = (omega(1) + omega(2)) / 2; % arithmetic mean picks guess in b/t bounds
    v0(1:num_sy:num_s) = omeguess;
    
    % get viability
    [~,~,~,risk_to_go] = pop_viability(v0,omeguess);
    
    % trace the line where we just meet the constraint
    [~,ind_10] = max(risk_to_go<(confidence+epsi),[],1);
    
    % compare this line to the 'correct' one from the max action case
    ind_off = sum(ind_10 - ind_10_max);
    
    % redefine bounds on omega
    if ind_off > 0 % increase penalty, not inducing enough action
        
        omega(1) = omeguess;
        
    else % enough action, but might be too high, make this guess the new upper bound
        
        omega(2) = omeguess;
        
    end
    
    % evaluate distance between values
    distance = (omega(2) - omega(1)) / omega(2);
    disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%')
    disp(['ind_off = ', num2str(ind_off)])
    disp(['%-diff = ', num2str(distance)])
    disp(['omega = ', num2str(round(omega(1),-6)), ', ', num2str(round(omega(2),-6))])
    disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%')
    
end

% output, take the larger of the bounds
penalty = omega(2);


end


