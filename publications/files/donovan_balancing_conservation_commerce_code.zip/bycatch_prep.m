% Pierce Donovan
% Bycatch Viability: defining program inputs
% bycatch_prep.m
% June 2020

% This script stores all of the biological and economic parameters in the
% bycatch management problem, as well as some useful functions for later
% use. Generates the Markov transition matrix via FFT method for converting
% a CF to PMF. Passes these to the parent script.

% Called by bycatch_parent.m

function [num,par,nb,MTM,v0,bell,npv,reg] = bycatch_prep

%% listing all biological/economic parameters (two clean structures, num and par)

% state and control sets
% leatherback turtles, x
num.x.min = 0; % extinction
num.x.max = 4000; % upper limit (just has to not interfere with tail)
num.x.step = 1; % bin size (except 0)
num.x.bin = num.x.max/num.x.step+1; % turtle discretization
num.x.state = linspace(num.x.min,num.x.max,num.x.bin)'; % turtle states on grid

% average daily gillnet setting, u
num.a.min = 0; % no action
num.a.max = 35; % max fishing days (unregulated case)
num.a.step = 1; % bin size
num.a.bin = num.a.max/num.a.step+1; % action discretization
num.a.state = linspace(num.a.min,num.a.max,num.a.bin)'; % levels of action on grid

% viability parameters
par.Delta = 0.05; % viability confidence (defined opposite of paper)
par.T = 100; % rolling window horizon (in years)

% economic parameters
par.beta = 0.97; % discrete discount factor
par.p = 6500; % price per ton swordfish
par.phi = 0.88; % expected tons swordfish per day
par.theta = 0.024; % expected number turtles per day
par.N = 500; % number of vessels
par.c = 160; % estimated cost parameter

% biological parameters
par.sigma = 0.53; % percent of females in bycatch
par.rho = 0.3; % percent turtles nesting
par.gamma = 80; % number of female hatchlings after 2 days
par.etaR = 0.03; % recruitment variation
par.etaM = 0.03; % mortality variation
par.m1 = 0.75; % 1st year mortality
par.m = 0.2; % other year mortality
par.y = 15; % years beyond first to maturity
par.K = 75000; % intraspecific competition


%% setting up stochastic dynamics and the transition matrix

% negative binomial means for different shocks
nb.recruitment.mu = @(X) par.gamma*par.rho*(1-par.m1)*(1-par.m)^par.y*X.*(1-X/par.K); % expected recruitment
nb.mortality.mu = @(X) par.m*X; % expected natural mortality
nb.bycatch.mu = @(A) par.N*par.theta*par.sigma*A; % expected fleet bycatch

% negative binomial variance (r) parameters
nb.bycatch.r = @(X) par.etaM*X;
nb.recruitment.r = @(X) par.etaR*par.rho*X;
nb.mortality.r = @(X) par.etaM*X;

% mean-to-p conversion for NB-distribution
mu2p = @(mu,r) r./(mu+r);
nb.recruitment.p = @(X) mu2p(nb.recruitment.mu(X),nb.recruitment.r(X));
nb.mortality.p = @(X) mu2p(nb.mortality.mu(X),nb.mortality.r(X));
nb.bycatch.p = @(X,A) mu2p(nb.bycatch.mu(A),nb.bycatch.r(X));
        
% make the three distribution objects, useful for debug
nb.recruitment.dist = @(X) makedist('Negative Binomial',nb.recruitment.r(X),nb.recruitment.p(X));
nb.mortality.dist = @(X) makedist('Negative Binomial',nb.mortality.r(X),nb.mortality.p(X));
nb.bycatch.dist = @(X,A) makedist('Negative Binomial',nb.bycatch.r(X),nb.bycatch.p(X,A));

% characteristic functions (don't work with X=0)
nb.recruitment.cf = @(t,X) nb.recruitment.p(X).^nb.recruitment.r(X).*(1-(1-nb.recruitment.p(X)).*exp(1i*t)).^(-nb.recruitment.r(X));
nb.mortality.cf = @(t,X) nb.mortality.p(X).^nb.mortality.r(X).*(1-(1-nb.mortality.p(X)).*exp(1i*t)).^(-nb.mortality.r(X));
nb.bycatch.cf = @(t,X,A) nb.bycatch.p(X,A).^nb.bycatch.r(X).*(1-(1-nb.bycatch.p(X,A)).*exp(1i*t)).^(-nb.bycatch.r(X));
cf = @(t,X,A) nb.recruitment.cf(t,X) .* nb.mortality.cf(-t,X) .* nb.bycatch.cf(-t,X,A); % characteristic function of the sum/difference


%% build the Markov transition matrix

% looping over levels of fishing action, generating a structure object
for A = 1:num.a.bin

    % generate MTM for given action level and sample populations
    mtm = cell2mat(arrayfun(@(X)pmf_fft(X,num.a.state(A),cf,num),num.x.state,'UniformOutput',false));
    
    % add matrix conditional on action to MTM structure
    MTM(A).a = sparse(mtm);
    
end % MTM loop


%% functions involving economic component of model

% profit function, and initial guess of value function
mu = @(A) par.N*(par.p*par.phi*A - par.c/2*A.^2); % expected profit, function of level
v0 = mu(ones(num.x.bin,1))/(1-par.beta); % present value from fishing 1 day forever

% initialize bellman equation, a function of action index
bell = @(A,v_old) mu(num.a.state(A)) + par.beta * MTM(A).a * v_old;

% expected present profit function
npv = @(mtm,policy) (eye(num.x.bin)-par.beta*mtm) \ mu(policy); % starting at t=0

% price instrument
reg.price = @(policy) (par.p*par.phi-par.c*policy)/(par.theta*par.sigma);

% quantity instrument (before rounding)
reg.quota = @(policy) par.N*par.theta*par.sigma*policy;


end % bycatch_prep.m

