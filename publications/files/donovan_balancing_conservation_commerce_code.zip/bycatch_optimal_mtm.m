% Pierce Donovan
% Bycatch Viability: grabbing the Markov transition matrix w.r.t. optimal policy
% bycatch_optimal_mtm.m
% May 2020

% This generates the Markov transition matrix conditional on a given policy
% function, reducing the structure of the matrix from 3D -> 2D. For each
% action, grab the relevant rows in each of the "pages" of the markov
% transition matrix. (Always loop over/match levels of action, not each
% state, otherwise you'll be here all week. There are way more states.)

% Called by bycatch_viability.m

function MTM_opt = bycatch_optimal_mtm(policy,MTM,num)

% look at what states use a given policy
states = 1:num.x.bin; % enumerate states for lookup
for n = 1:num.a.bin

    % building part of the transition matrix, given action (index form)
    idx = states(policy.idx==n); % find relevant rows to grab
    MTM_opt(idx,:) = MTM(n).a(idx,:); % multilevel indexing easy with structures
    
end % looping over action level

end % bycatch_optimal_mtm.m

