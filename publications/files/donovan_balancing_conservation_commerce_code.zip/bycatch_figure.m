% Pierce Donovan
% Bycatch Viability: illustrations
% bycatch_figure.m
% July 2020

% This script recreates the three figures (social planner value function,
% reglator's instruments, price decomposition) in Section 4 of "Balancing
% conservation and commerce."

% Called by bycatch_parent.m

function bycatch_figure(do_save,policy,value,prob,num,reg)

%% value function decomposition and density plot

% first figure, with actual extinction threshold
fig = figure;
pos1 = [0.15 0.35 0.71 0.63]; % tweak to get subplots aligned
subplot('position',pos1)

% value function decomposition, left axis
h = plot(num.x.state,[value.profit,(value.profit+value.shadow),value.shadow]*10^-6);
h(1).Color = [127,201,127]/256; h(1).LineWidth = 2.5; h(1).LineStyle = '-'; % value.profits
h(2).Color = [190,174,212]/256; h(2).LineWidth = 2.5; h(2).LineStyle = '--'; % value.net
h(3).Color = [253,192,134]/256; h(3).LineWidth = 2.5; h(3).LineStyle = ':'; % value.shadow
hold on
h(4) = plot(num.x.state,zeros(num.x.bin,1),'--','color',[.5,.5,.5]); % zero line

% labels for the left axis
xlim([500,2000]) % zoom in on interesting region
set(gca,'XTickLabel',{}); % because I'm putting it below the sub-figure
ylim([-900,500])
set(gca,'YTick',-800:200:400);
ylabel('$ (millions)')

% optimal fishing level, right axis
yyaxis right
h(5) = plot(num.x.state,policy.level,'color',[158,202,225]/256,'linewidth',2.5);
ylabel('Fishing effort (vessel-days)')
set(gca,'YColor',[0 0 0]);
ylim([0,15])

% legend
legend([h(2),h(1),h(3),h(5)],{'V^\Omega(X)',...
    'V(X)',...
    '\omega(X)',...
    'A^\Omega(X)'},...
    'location','southeast','FontSize',14,'color','none');

% bottom density sub-figure
pos2 = [0.15 0.135 0.71 0.205];
subplot('position',pos2)
plot(num.x.state,prob.density,'linewidth',2.5)
hold on
plot(find(prob.kernel,1)*[1,1],[0,1.5e-3],'r--','linewidth',2.5) % extent of kernel
xlim([500,2000])
ylabel('PMF')
xlabel('Leatherback abundance, X')
set(gca,'YTick',[0,1e-3],'YTickLabel',{'0','10^{-3}'});

% some manual paper tweaks to get figure presentation right
fig.Position = [100,100,fig.Position(3),0.94*fig.Position(3)];
fig.PaperSize = fig.PaperPosition([3,4]);
set(findall(gcf,'type','axes'),'FontSize',16);
set(findall(gcf,'type','text'),'FontSize',18,'FontWeight','Normal');

% exporting
if do_save
    fig.Color = 'none'; set(findall(gcf,'type','axes'),'color','none'); % transparent background
    fig.InvertHardcopy = 'off';
    saveas(fig,'fig/social_planner.pdf')
end


%% regulator price and quota instruments

% price on the left axis
fig = figure;
h = plot(num.x.state,reg.price(policy.level)/1000);
xlim([1000,2000]) 
h(1).Color = [141,160,203]/256; h(1).LineWidth = 3; % price
hold on
xlabel('Leatherback abundance, X')
ylabel('Leatherback bycatch price ($K)')

% quota on the right one
yyaxis right
h(2) = plot(num.x.state,reg.quota(policy.level),'linewidth',3);
h(2).Color = [252,141,98]/256; h(2).LineWidth = 3; % quantity
ylabel('Leatherback quota')
set(gca,'YColor',[0 0 0]);

% legend
legend([h(1),h(2)],{'P(A^\Omega(X))','Q(A^\Omega(X))'},...
    'location','south','FontSize',14,'color','none');

% manual presentation tweaks
fig.PaperSize = fig.PaperPosition([3,4]);
set(findall(gcf,'type','axes'),'FontSize',16);
set(findall(gcf,'type','text'),'FontSize',18,'FontWeight','Normal');

% export
if do_save
    fig.Color = 'none'; set(gca,'color','none'); % transparent background
    fig.InvertHardcopy = 'off';
    saveas(fig,'fig/regulator.pdf')
end


%% price decomposition figure

% derivative plots, want to avoid plotting the jumps from action increase
fig = figure;
h = plot(num.x.state(2:end),[diff(csaps(num.x.state,value.shadow,.00001,num.x.state)),...
    diff(csaps(num.x.state,value.profit,.00001,num.x.state)),...
    diff(csaps(num.x.state,value.shadow,.00001,num.x.state))+diff(csaps(num.x.state,value.profit,.00001,num.x.state))]/1000,...
    'linewidth',3);
% h = plot(num.x.state(2:end),[diff(value.shadow), diff(value.profit),...
%     diff(value.shadow)+diff(value.profit)]/1000,'linewidth',3);
h(1).LineStyle = ':'; % domega
h(2).LineStyle = '-.'; % dprofit
h(3).LineStyle = '-'; % sum
hold on
h(4) = plot(num.x.state,reg.price(policy.level)/1000,'linewidth',3,'linestyle','-'); % price
xlim([800,1800]) 
hold on
xlabel('Leatherback abundance, X')
ylabel('$ (thousands)')

% legend (which needs manual tweaking in acrobat...)
legend([h(1),h(2),h(3),h(4)],{'\partial\omega(X)/\partialX',...
    '\partialV(A^\Omega(X))/\partialX',...
    '\partial\omega(X)/\partialX + \partialV(A^\Omega(X))/\partialX',...
    'P(A^\Omega(X))'},...
    'location','northeast','FontSize',14,'color','none');

% manual presentation tweaks
fig.PaperSize = fig.PaperPosition([3,4]);
set(findall(gcf,'type','axes'),'FontSize',16);
set(findall(gcf,'type','text'),'FontSize',18,'FontWeight','Normal');

% export
if do_save
    fig.Color = 'none'; set(gca,'color','none'); % transparent background
    fig.InvertHardcopy = 'off';
    saveas(fig,'fig/price_decomposition.pdf')
end


end % bycatch_figure.m

