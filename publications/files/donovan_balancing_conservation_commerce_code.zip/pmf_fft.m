% Pierce Donovan
% Bycatch Viability: characteristic function to PMF
% pmf_fft.m
% July 2020

% This script takes advantage of the fact that characteristic functions on
% combinations of random variables are often easier to write down than
% PMFs. We can use an inverse Fourier transform to recover the PMF given a
% CF with little error and improved speed relative to simulation-based or
% convolution-dependent methods. I learned how to make this work by
% skimming Viktor Witkovsky's papers on numerical inversion of the CF and
% his CharFunTool package for Matlab.

% Called by bycatch_prep.m

function pmf = pmf_fft(X,A,cf,num)

if X == 0 % degenerate case, stay at zero
    
    pmf = [1,zeros(1,num.x.bin-1)];
    
else % use inverse [discrete fast] Fourier transform to go from CF->PMF
    
    % setting up domain to map from t to x space
    D = num.x.max/2; % specific to this problem, captures PMF regardless of X,A
    xmin = -D; xmax = D; % initial domain of PMF
    x = 0:(xmax-xmin); % points on PMF to be evaluated, have to shift domain to 0->2pi
    n = length(x); % number of evaluation points
    omega = x/n; % omega from 0 to 1, as CF repeats
    
    % the integral to be evaluated, want inverse so throw a minus sign in
    % CF, also want to shift PMF to work with Fourier 0->2pi repetition
    integrand = cf(-2*pi*omega,X,A) .* exp(1i*2*pi*omega*xmin);

    % PMF calculation and tweaks to map from a delta-x to the x value
    pmf = real(ifft(integrand)); % voodoo magic
    
    % fix out-of-bounds, pad opposite ends with zeros (the weird logic is
    % because sum(empty matrix) = 0)
    pmf = [zeros(1,max(sum(X+(-D:D)>num.x.max),0)),...
        sum(pmf(X+(-D:D)<=0))*ones(1,~isempty(pmf(X+(-D:D)<=0))),...
        pmf((X+(-D:D)>0)&(X+(-D:D)<num.x.max)),...
        sum(pmf(X+(-D:D)>=num.x.max))*ones(1,~isempty(pmf(X+(-D:D)>=num.x.max))),...
        zeros(1,max(sum(X+(-D:D)<0),0))];

    % kill small values, re-normalize
    pmf(pmf < 1e-5) = 0;
    pmf = pmf/sum(pmf);
    
end

end
 
 