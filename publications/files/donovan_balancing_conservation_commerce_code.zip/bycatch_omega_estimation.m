% Pierce Donovan
% Bycatch Viability: estimation of extinction loss
% bycatch_omega_estmation.m
% May 2020

% Estimates the value of a shadow value function parameter used to motivate
% costly action in population viability problems. First calculates the
% viability kernel, which tells us which states the viability objective is
% attainable. Then candidate parameters are tried until the lowest value is
% found that incentivizes enough conservation effort to meet the viability
% objective within all kernel states. An easy check of this simply compares
% the number of states in attainment. The loop converges once the upper and
% lower bounds are within a certain tolerance of each other (each step
% proposes an average between the two, and this average replaces the upper
% or lower bound depending on if it is successful, or not. The last
% successful candidate is passed to the parent function.

% Called by bycatch_parent.m

function omega_out = bycatch_omega_estimation(MTM,v0,bell,num,par,npv)

%% benchmark: where can we meet the chance constraint with no fishing?

% finding the best likelihood of survival to T for all states
prob_thresh = sparse(1,1,1,num.x.bin,1); % indicator function for absorbing state
for i = 1:par.T % fast multiply out to T
    % no fishing, action index = 1
    prob_thresh = MTM(1).a*prob_thresh;
end

% grabbing the viability kernel
kernel = prob_thresh < par.Delta;


%% omega estimation: what is the smallest value incentivizes success within the kernel?

% loop, test mean of bounds, if good, new upper bound, bad, lower bound, and converge within some tolerance
omega = -[1e10, 1e12]; % initial range to consider, omega_0
tol = 0.05; % loop tolerance, simple ending condition
distance = 1;
while distance > tol % tolerance percentage-diff in bounds
    
    % set up next guess (between current bounds)
    omeguess = (omega(1) + omega(2)) / 2;
    
    % get portion of state space meeting viability goal
    [~,~,prob] = bycatch_viability(v0,omeguess,bell,MTM,num,par,npv);
    
    % compare attainment states to what is possible (the kernel). can just
    % compare the sum of successful states (omega-incentivized value is
    % hitting a slightly easier viability target to mitigate precision errors)
    num_missing_states = sum(kernel) - sum(prob.kernel);
    
    % tighten bounds on omega given this result
    if num_missing_states > 0 % increase penalty, not inducing enough action
        omega(1) = omeguess;
    else % enough action, but might be too high, make this guess the new upper bound
        omega(2) = omeguess;
    end
    
    % evaluate distance between values (for stopping criterion)
    distance = (omega(2) - omega(1)) / omega(2);
    
    % mention estimation progress to user
    disp(['# states in kernel not in attainment: ', num2str(num_missing_states)])
    disp(['new bounds = ', num2str(-omega(1)/10^9,3), ', ', num2str(-omega(2)/10^9,3), ' ($ billion)'])
    disp(['%-diff between bounds: ', num2str(distance)])
    disp('%%%%%%%%%%%%%%%%%%%%%%%%%%%')
    
end % estimation loop

% output, take the larger of the bounds
omega_out = omega(2);
disp(['lowest successful Omega: ', num2str(-omega(2)/10^9,3), ' ($ billion)'])

end % bycatch_omega_estimation.m

