% Pierce Donovan
% Bycatch Viability: infinite-horizon dynamic optimization script
% bycatch_vfi.m
% May 2020

% Value function iteration (VFI) algorithm that spits out value and policy
% functions for a provided Bellman equation.

% I added a simple tweak to accomodate the "V(0) = Omega" constraint. The
% viability model pegs the value of the extinction threshold to a given
% loss Omega. This refreshes after the maximization step, and repeated
% application of the Bellman operator propagates this value to neighboring
% states. This takes a while if the furthest state from extinction is far
% away or there is a tendency for the state to increase at high levels.

% Called by bycatch_viability.m

function [v_new, a_idx] = bycatch_vfi(v_old,Omega,bell,num)

%% solve for fixed point

% update initial guess of value function with current guess of Omega
v_old(1) = Omega; % replace threshold state value with current omega estimate

% loop time
eps_vfi = 0.05; % stopping criterion (proportional terms)
norm = @(v_new,v_old) max(abs((v_new-v_old)./v_old)); % infinity-norm (largest element) [conservative]
dv = eps_vfi + 1; % start w/ value greater than epsilon
while dv > eps_vfi
    
    % for each possible control value; bellman operator a function of action index
    v_mat = zeros(num.x.bin,num.a.bin);
    for n = 1:num.a.bin
        v_mat(:,n) = bell(n,v_old);
    end
    
    % getting value function, policy function that maximizes value
    [v_new,a_idx] = max(v_mat,[],2); % Bellman operator
    v_new(1) = Omega; % reset viability state value, don't care about action assigned here (yet)
    
    % calculate change in value function
    dv = norm(v_new,v_old);
    v_old = v_new;
    
end % vfi loop

end % tmf_vfi.m

