% Pierce Donovan
% Bycatch Viability: actually running the shadow value viability method
% bycatch_viability.m
% May 2020

% This does the heavy lifting for bycatch_parent.m, organizing helper functions
% to caluclate the optimal policy function for a given shadow value and
% evaluate the long-run viability and cost of the chosen program.

% Called by bycatch_parent.m, bycatch_omega_estimation.m

function [policy,value,prob] = bycatch_viability(v0,Omega,bell,MTM,num,par,npv)

%% compute optimal value and policy functions

% do VFI, conditional on the current estimate of Omega
[value.net,policy.idx] = bycatch_vfi(v0,Omega,bell,num);

% shouldn't prescribe action at extinction, can smooth out
policy.idx(1) = 1;
policy.idx = cummax(policy.idx);

% literal policy function, not index
policy.level = num.a.state(policy.idx);


%% new transition matrix conditional on the policy function (2D now)

% sub-selection from the action "pages" of the MTM structure
MTM_opt = bycatch_optimal_mtm(policy,MTM,num);


%% calculate future joint population density, probability of violating constraint by season T

% starting state = 1500 (post-multiply)
prob.density = sparse(1,3001,1,1,num.x.bin);

% expectation of function with Markov: E[f_k(x)] = X_0'*B^T*f(x) (pre-multiply)
prob.threshold = sparse(1,1,1,num.x.bin,1); % indicator function for absorbing state

% loop is fastest way to multiply matricies with a vector on the end
for i = 1:par.T
    prob.density = prob.density*MTM_opt;
    prob.threshold = MTM_opt*prob.threshold;
end
prob.density = full(prob.density)';
prob.threshold = full(prob.threshold);

% grab the viability kernel
prob.kernel = prob.threshold < par.Delta; % precision errors can creep here, consider fuzzing par.Delta


%% compute present shadow value of the viability restriction

% solving for v with unmodified bellman operator
value.profit = npv(MTM_opt,policy.level);

% difference out the profit from the value function, flip shadow value sign
value.shadow = value.net - value.profit; % shadow value also positive


end % bycatch_viability.m

