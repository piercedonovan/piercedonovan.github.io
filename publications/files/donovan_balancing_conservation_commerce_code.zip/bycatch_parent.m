% Pierce Donovan
% Bycatch Viability: just-press-play script
% bycatch_parent.m
% June 2020

% This calls all of the auxillary scripts needed for "Balancing
% Conservation and Commerce," Donovan and Springborn, 2020.

% bycatch_prep.m defines key parameters, functions, the Markov
% transition matrix and the Bellman operator.

% Once values are loaded, you can choose to run the full Omega-estimation
% (bycatch_omega_estimation.m) or take the output for granted by turning
% the estimation off and using the number I've provided below. Saves a
% quite a bit of time depending on how large you set the action or state spaces.

% Given Omega, it is time to find the optimal fishing policy for the social
% planner. Running bycatch_viability.m provides several objects of interest
% besides the policy, like the value function, expected present profit
% function, shadow value function, the likelihood of survival, and the
% long-run population PMF.

% This script then calls on bycatch_figure.m to plot several items of
% interest that made it into the manuscript.


%% setting parameters, functions, transition matricies, etc.

% drop things in memory
clear; close all; clc

% defining program inputs
[num,par,nb,MTM,v0,bell,npv,reg] = bycatch_prep;


%% estimation of the extinction loss [Omega]

% if I have a pre-computed value, this saves a minute or two
estimation = 0;
if estimation % run the Omega estimation procedure
    Omega = bycatch_omega_estimation(MTM,v0,bell,num,par,npv);
else % pre-computed value
    Omega = -118 * 10^9; % -74.7 * 10^9; % absolutely massive (at extinction)
end


%% shadow value viability program, given an Omega above

[policy,value,prob] = bycatch_viability(v0,Omega,bell,MTM,num,par,npv);


%% some quick statistics

stats.mean = num.x.state'*prob.density;
stats.sd = sqrt(((num.x.state'-stats.mean).^2)*prob.density);
stats.sample = [500,1500,2500];
stats.effort = policy.level(1+stats.sample);
stats.bycatch = nb.bycatch.mu(stats.effort);
MTM_opt = bycatch_optimal_mtm(policy,MTM,num);
temp = npv(MTM_opt,policy.level);
stats.npv_profits = temp(1+stats.sample);
stats.profits = par.N*(par.p*par.phi*stats.effort - par.c/2*stats.effort.^2);
stats.shadow = value.shadow(1+stats.sample);
temp = [diff(value.profit),diff(value.shadow)];
stats.dprofit = temp(stats.sample,1);
stats.dshadow = temp(stats.sample,2);


%% figures (please see each plotting script for more info on outputs)

% save output?
do_save = 0;

% bring up the figures in the paper
bycatch_figure(do_save,policy,value,prob,num,reg)


