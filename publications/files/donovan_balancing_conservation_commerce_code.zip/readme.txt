Pierce Donovan
Assistant Professor, Economics
Connecticut College
pdonovan@conncoll.edu
July 2022

The Matlab code in this directory uses the shadow value viability approach (Donovan and Springborn 2022, Donovan et al. 2019) to solve the multi-species fishery management problem in "Balancing Conservation and Commerce." Open bycatch_parent.m to run the suite. Documentation on each of the scripts is found in the parent file and each of the auxillary files. Questions/comments can be directed toward Pierce Donovan.

This project faced some bioeconomic challenges that complicated generation of the Markov transition matrix, and the matrix is not terribly sparse either, thus computation here is somewhat slower than my other applications. I also wrote all of this during my PhD and have learned a lot of new techniques for implementing shadow value viability since then, and there will be a new version of my SVV suite coming out in the near future.

Copyright 2022 Pierce Donovan (CC BY-NC 3.0 US). pdonovan@conncoll.edu
Non-commercial use is allowed for teaching and research purposes. You are free to share and adapt (replicate, extend) this material.

